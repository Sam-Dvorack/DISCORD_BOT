# DISCORD BOT
Discord bot using discord.js-commando
